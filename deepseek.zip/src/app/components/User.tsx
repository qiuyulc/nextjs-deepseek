import { SignedIn,  UserButton } from "@clerk/nextjs";

export default function Page() {


  return (
    <div>
      <h1>My App</h1>
      <SignedIn>
        <UserButton />
      </SignedIn>
    </div>
  );
}
